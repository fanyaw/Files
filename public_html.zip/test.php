<?php

echo $var;

?>