<?php
require_once("../../../../resources/config.php");

if(isset($_GET['id'])) {
	$query = query("DELETE FROM reports WHERE report_id = " . escape_string($_GET['id']). "");
	confirm($query);

	set_message("Report #" . $_GET['id'] . " deleted successfully!");
	redirect("../../../admin/index.php?reports");

} else {

	redirect("../../../admin/index.php?reports");

}




?>