<?php include("includes/header.php") ?>


<?php include("includes/nav.php") ?>



	<div class="jumbotron">
		<?php display_message(); ?>
		<h1 class="text-center">Home</h1>
	</div>


	<?php 
	/*testing helper functions
	$sql = "SELECT * FROM users";
	$result = query($sql);

	confirm($result);

	$row = fetch_array($result);
	echo $row['username'];
	*/
	?>

<?php include("includes/footer.php") ?>