<?php require_once("../resources/config.php"); ?>
<?php include(TEMPLATE_FRONT . DS . "header.php") ?>

<?php

	//insert orders by products into report
	process_transaction();


?>


<!-- Page Content -->
<div class="container">

	<h1 class="text-center">THANK YOU</h1>

 </div><!--Main Content-->


<?php include(TEMPLATE_FRONT . DS . "footer.php") ?>