
<div class="row">

    <h1 class="page-header">
       Reports
    </h1>
    <h4 class="text-center bg-success"><?php display_message(); ?></h4>
    <table class="table table-hover">
        <thead>
            <tr>
               <th>Id</th>
               <th>Product Id</th>
               <th>Product Title</th>
               <th>Order Id</th>
               <th>Product Price</th>
               <th>Product Quantity</th>
               <th>Delete</th>
            </tr>
        </thead>
        <tbody>
            <?php get_reports(); ?>
        </tbody>
    </table>

</div>
