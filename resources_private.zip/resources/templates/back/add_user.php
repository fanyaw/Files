

<div class="col-md-12">

    <div class="row">
        <h1 class="page-header">Add User</h1>

        <p><?php add_user(); ?></p>
        
    </div>
               

    <!-- enctype="multipart/form-data"  -> add multi files feature -->
    <form action="" method="post" enctype="multipart/form-data">


        <div class="col-md-8">

            <div class="form-group">
                <label for="username">User Name </label>
                <input type="text" name="username" class="form-control">  
            </div>

            <div class="form-group">
                <label for="email">Email </label>
                <input type="text" name="email" class="form-control">  
            </div>

             <div class="form-group">
                <label for="password">Password </label>
                <input type="password" name="password" class="form-control">  
            </div>
      

        </div><!--Main Content-->


    	<!-- SIDEBAR-->
        <aside id="admin_sidebar" class="col-md-4">

         
            <div class="form-group">
                <input type="submit" name="add_user" class="btn btn-primary btn-lg" value="Add User">
            </div>


        </aside><!--SIDEBAR-->

    
    </form>


</div>
        
