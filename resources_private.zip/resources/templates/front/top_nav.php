    <!-- Brand and toggle get grouped for better mobile display -->
    <div class="navbar-header">
        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
        </button>
        <a class="navbar-brand" href="index.php">Store Name</a>
    </div>

    <!-- Collect the nav links, forms, and other content for toggling -->
    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
        <ul class="nav navbar-nav">
            <li>
                <a href="shop.php">All Products</a>
            </li>
             <li>
                <a href="checkout.php">Checkout</a>
            </li>
            <li>
                <a href="contact.php">Contact</a>
            </li>
<?php 
        //if logged in
        if(isset($_SESSION['username'])) {
            $username = $_SESSION['username'];

            $admin = <<<DELIMETER
            <li>
                <a href="admin/index.php">Admin</a>
            </li>
            <li class="dropdown">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="fa fa-user"></i>{$username}<b class="caret"></b></a>
                    <ul class="dropdown-menu">
                       
                        <li class="divider"></li>
                        <li>
                            <a href="admin/logout.php"><i class="fa fa-fw fa-power-off"></i> Log Out</a>
                        </li>
                    </ul>
                </li>  

DELIMETER;
            echo $admin;

        } 
?>



<?php 
        //if not logged in
        if(!isset($_SESSION['username'])) {

            $login = <<<DELIMETER
            <li>
                <a href="login.php">Login</a>
            </li> 


DELIMETER;
            echo $login;



        } 
?>

        </ul>

    </div>
    <!-- /.navbar-collapse -->



