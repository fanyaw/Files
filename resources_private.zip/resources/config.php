<?php
//turn on output buffering, it will send request to php
ob_start(); 
//turn on session to have extra features
session_start();
//session_destroy();

// IF it is defined, put it as null; if not, define it as DS
defined("DS") ? null : define("DS", DIRECTORY_SEPARATOR);
 
//echo __DIR__;  //gives the directory where it echo from
//echo __FILE__; // gives the file where it from

// Defining Path with constants
defined("TEMPLATE_FRONT") ? null : define("TEMPLATE_FRONT", __DIR__ . DS . "templates/front");

defined("TEMPLATE_BACK") ? null : define("TEMPLATE_BACK", __DIR__ . DS . "templates/back");

defined("UPLOAD_DIRECTORY") ? null : define("UPLOAD_DIRECTORY", __DIR__ . DS . "../public_html/resources/uploads");

//echo TEMPLATE_FRONT; //test

// Defining/creating database 
defined("DB_HOST") ? null : define("DB_HOST", "localhost");

defined("DB_USER") ? null : define("DB_USER", "ecomtest_user");

defined("DB_PASS") ? null : define("DB_PASS", "Leah1618!");

defined("DB_NAME") ? null : define("DB_NAME", "ecomtest_db");

// Defining database connection
$connection = mysqli_connect(DB_HOST, DB_USER, DB_PASS, DB_NAME);

require_once("functions.php");

require_once("cart.php"); 








?>